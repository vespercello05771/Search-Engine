# Add your import statements here
import nltk
from nltk.corpus import wordnet as wn



# Add any utility functions here